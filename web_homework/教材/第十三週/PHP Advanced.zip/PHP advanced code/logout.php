<?php
	// Start the session
	session_start();
	$_SESSION["sessionEmail"] = null;
	header('Location: form.php');
?>