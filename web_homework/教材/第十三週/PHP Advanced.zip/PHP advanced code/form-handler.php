<?php
	// Start the session
	session_start();
	$email = $_POST["email"];
	$password = $POST["password"];
	if(isValidUser($email)) {
		$_SESSION["sessionEmail"] = $email;
		header('Location: main.php');
	} else {
		header('Location: form.php');
	}
	
	function isValidUser($email) {
		if($email == "wentin.lee@gmail.com") {
			return true;
		} else {
			return false;
		}
	}
?>