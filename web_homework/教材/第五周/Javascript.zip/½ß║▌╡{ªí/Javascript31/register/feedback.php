<?php
header("Access-Control-Allow-Origin: *");
sleep(5); 

echo "<h3>歡迎您 {$_POST['name']}</h3>";
echo "<h3>請確認以下資料</h3>";
echo "<h3>帳號: {$_POST['username']}</h3>";
echo "<h3>密碼: {$_POST['password']}</h3>";
echo "<h3>信箱: {$_POST['email']}</h3>";
?>

<img src="images/success.jpg">
