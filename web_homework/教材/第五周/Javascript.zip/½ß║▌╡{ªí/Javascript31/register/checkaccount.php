<?php
header("Access-Control-Allow-Origin: *");
$Usernames = array ("admin", "charlie", "sam");

sleep(3);

if ($_GET["username"] == "") {
	echo "invalid";
} else if (in_array( $_GET["username"], $Usernames )) {
	echo "invalid";
} else {
	echo "ok";
}

?>
