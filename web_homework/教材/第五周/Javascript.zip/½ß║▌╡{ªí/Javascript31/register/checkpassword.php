<?php
header("Access-Control-Allow-Origin: *");
sleep(3);

if (strlen($_POST["password"]) > 3) {
	echo "ok";
} else {
	echo "invalid";
}

?>